import React from 'react'

const CounterName = () => {
  return (
    <div>CounterName</div>
  )
}
export default CounterName;