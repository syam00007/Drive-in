import React from 'react'

const Settings = () => {
  return (
    <div><h1><strong>Settings</strong></h1></div>
  )
}
export default Settings;