import React from 'react'

const Mainpaje = () => {
  return (
    <div style={{
      position: "relative",
      left: "8px",}}>
        <h1 style={{fontFamily:"Times New Roman"}}>Counter Name:</h1>
        <center><h1 style={{color:"DodgerBlue", fontFamily:"Times New Roman"}}>Categories Are Not Available in this Counter</h1> </center>
    </div>
  )
}
export default Mainpaje;
