package com.rs.www.dto;

public class CategoryDTO {
    private String name;
    private Long counterId;

    // Getters & Setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getCounterId() {
        return counterId;
    }
    public void setCounterId(Long counterId) {
        this.counterId = counterId;
    }
}
