package com.rs.www.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;

import java.util.List;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String name;

	@ManyToOne
	@JoinColumn(name = "counter_id")
	private CPModel counter;

	@OneToMany(mappedBy = "category")
	@JsonIgnore
	private List<Items> items;

	// Manually added getters/setters
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public CPModel getCounter() { return counter; }
	public void setCounter(CPModel counter) { this.counter = counter; }
}